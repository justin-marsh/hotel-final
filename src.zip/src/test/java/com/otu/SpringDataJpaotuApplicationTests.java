package com.otu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpaotuApplicationTests {

	@Test
	void contextLoads() {
	}

}
